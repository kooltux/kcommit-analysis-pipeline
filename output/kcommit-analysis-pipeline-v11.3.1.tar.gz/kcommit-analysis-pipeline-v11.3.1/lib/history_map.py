"""Stage 03 helper: build a Kconfig-symbol → source-file history map.

Walks git commits in the requested mode (range / sampled / full / disabled)
and records which source files were touched alongside each changed Kconfig symbol.
Parallel git-show calls are used via ThreadPoolExecutor; a serial fallback
is used when max_workers <= 1. Failure rate is capped by
history_mapping.max_failure_rate (default 0.05).
"""
import os
import re
import sys
from concurrent.futures import ThreadPoolExecutor, as_completed

from lib.gitutils import list_rev_commits, show_path_history

import hashlib as _hashlib
import tempfile as _tempfile



def _gitshow_cache_path(cache_dir, key):
    """Return the sharded file path for *key* inside gitshow_cache/.

    Layout: gitshow_cache/<key[0:2]>/<key[2:4]>/<key>
    This mirrors git's own object store sharding and avoids filesystem
    congestion when the cache grows to tens of thousands of entries.
    """
    return os.path.join(cache_dir, 'gitshow_cache',
                        key[:2], key[2:4], key)


def _gitshow_cache_get(cache_dir, rev, path):
    """Return cached git-show result or None if not cached."""
    if not cache_dir:
        return None
    key   = _hashlib.sha256(f'{rev}:{path}'.encode()).hexdigest()[:24]
    fpath = _gitshow_cache_path(cache_dir, key)
    if os.path.exists(fpath):
        try:
            with open(fpath, 'r', encoding='utf-8', errors='replace') as f:
                return f.read()
        except Exception:
            return None
    return None


def _gitshow_cache_put(cache_dir, rev, path, text):
    """Persist a git-show result to disk cache."""
    if not cache_dir:
        return
    key   = _hashlib.sha256(f'{rev}:{path}'.encode()).hexdigest()[:24]
    fpath = _gitshow_cache_path(cache_dir, key)
    os.makedirs(os.path.dirname(fpath), exist_ok=True)
    try:
        with open(fpath + '.tmp', 'w', encoding='utf-8') as f:
            f.write(text or '')
        os.replace(fpath + '.tmp', fpath)
    except Exception:
        pass



OBJ_LINE_RE = re.compile(r'^(obj-[^\s:+?=]+)\s*[:+]?=\s*(.+)$', re.M)


def build_history_config_map(cfg, base_map, cache_dir, progress_callback=None):
    """Build a merged config_to_paths dict by sampling historical Makefiles."""
    hm = cfg.get('history_mapping', {})
    if not hm.get('enabled', True):
        return {'mode': 'disabled', 'snapshots': [], 'config_to_paths': base_map}

    commits = list_rev_commits(cfg)
    if not commits:
        return {'mode': hm.get('mode', 'range'),
                'snapshots': [],
                'config_to_paths': base_map}

    sample_step  = int(hm.get('sample_step', 1000))
    max_probe    = int(hm.get('max_commits_per_probe', 256))
    max_workers  = int((cfg.get('collect', {}) or {}).get('history_workers', 8))

    interesting_paths = _guess_makefiles_from_map(base_map)

    # ── sample revision list ──────────────────────────────────────────────────
    sampled = []
    if hm.get('mode', 'range') == 'range':
        sampled.append(cfg['kernel']['rev_old'])
        idx = sample_step
        while idx < len(commits):
            sampled.append(commits[idx - 1])
            idx += sample_step
        sampled.append(cfg['kernel']['rev_new'])
    else:
        sampled = [cfg['kernel']['rev_old'], cfg['kernel']['rev_new']]

    seen_revs   = set()
    unique_revs = []
    for r in sampled[:max_probe]:
        if r not in seen_revs:
            seen_revs.add(r)
            unique_revs.append(r)

    tasks = [(rev, mk) for rev in unique_revs for mk in interesting_paths]
    total = len(tasks)
    results = {}

    max_failure_rate = float(hm.get('max_failure_rate', 0.05))

    if max_workers > 1 and total > 0:
        try:
            def _fetch(task):
                rev, mk = task
                cached = _gitshow_cache_get(cache_dir, rev, mk)
                if cached is not None:
                    return rev, mk, cached
                text = show_path_history(cfg, rev, mk)
                _gitshow_cache_put(cache_dir, rev, mk, text or '')
                return rev, mk, text

            done_count   = [0]
            failed_tasks = []

            with ThreadPoolExecutor(max_workers=max_workers) as executor:
                future_map = {executor.submit(_fetch, t): t for t in tasks}
                for future in as_completed(future_map):
                    try:
                        rev, mk, text = future.result()
                    except Exception as exc:
                        rev, mk = future_map[future]
                        text = None
                        failed_tasks.append((rev, mk, str(exc)))
                    results[(rev, mk)] = text
                    done_count[0] += 1
                    if progress_callback:
                        progress_callback(done_count[0], total)

            if failed_tasks:
                failure_rate = len(failed_tasks) / max(total, 1)
                if failure_rate > max_failure_rate:
                    raise RuntimeError(
                        f'{len(failed_tasks)}/{total} git-show tasks failed '
                        f'({failure_rate:.0%}). First error: {failed_tasks[0][2]}')
                print(
                    f'\nWARNING: {len(failed_tasks)}/{total} git-show tasks failed '
                    f'(below {max_failure_rate:.0%} threshold, continuing with partial data)',
                    file=sys.stderr)

        except RuntimeError:
            raise
        except Exception:
            # Non-RuntimeError failure of the executor itself: fall back to serial
            results = _serial_fetch(cfg, tasks, progress_callback)
    else:
        results = _serial_fetch(cfg, tasks, progress_callback)

    # ── assemble snapshots ────────────────────────────────────────────────────
    snapshots = []
    for rev in unique_revs:
        snap = {'rev': rev, 'config_to_paths': {}}
        for mk in interesting_paths:
            text = results.get((rev, mk))
            if not text:
                continue
            rel_dir = os.path.dirname(mk)
            parsed  = _parse_makefile_blob(rel_dir, text)
            for sym, paths in parsed.items():
                snap['config_to_paths'].setdefault(sym, set()).update(paths)
        snap['config_to_paths'] = {k: sorted(v) for k, v in snap['config_to_paths'].items()}
        snapshots.append(snap)

    # ── merge all snapshots + base_map ────────────────────────────────────────
    merged = {}
    for snap in snapshots:
        for sym, paths in snap['config_to_paths'].items():
            merged.setdefault(sym, set()).update(paths)
    for sym, paths in base_map.items():
        merged.setdefault(sym, set()).update(paths)
    merged = {k: sorted(v) for k, v in merged.items()}

    return {
        'mode':            hm.get('mode', 'range'),
        'snapshots':       snapshots,
        'config_to_paths': merged,
    }


def _serial_fetch(cfg, tasks, progress_callback):
    # Uses disk cache for each (rev, path) pair when available.
    results = {}
    for i, (rev, mk) in enumerate(tasks):
        results[(rev, mk)] = show_path_history(cfg, rev, mk)
        if progress_callback:
            progress_callback(i + 1, len(tasks))
    return results


def _guess_makefiles_from_map(base_map):
    makefiles = set()
    for paths in base_map.values():
        for p in paths:
            makefiles.add(os.path.join(os.path.dirname(p), 'Makefile'))
    return sorted(makefiles)


def _parse_makefile_blob(rel_dir, text):
    out = {}
    for m in OBJ_LINE_RE.finditer(text):
        selector = m.group(1)
        rhs      = m.group(2)
        if 'CONFIG_' not in selector:
            continue
        sym = (selector.split('$(')[-1].rstrip(')')
               if '$(' in selector else None)
        if not sym or not sym.startswith('CONFIG_'):
            continue
        for token in rhs.split():
            if token.endswith('.o'):
                src = os.path.normpath(os.path.join(rel_dir, token[:-2] + '.c'))
                out.setdefault(sym, set()).add(src)
    return out
