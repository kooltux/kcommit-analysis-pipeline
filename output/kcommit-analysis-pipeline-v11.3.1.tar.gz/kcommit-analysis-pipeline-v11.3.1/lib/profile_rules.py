"""Profile and rule loading for kcommit-analysis-pipeline.

v9.12 changes:
  - compiled_rules.json uses a deduplicated schema:
      { "rules": { rule_name: {patterns…} }, "profiles": { name: { "rules": {rule_name: {weight}}, "merged": {…} } } }
    Rule pattern data is stored once even when shared across profiles.
  - compile_rules_for_config() writes the new schema.
  - load_profile_rules() inflates it back to the in-memory form expected by
    scoring.py / prefilter.py: { profile_name: { "merged": {…}, "rules": { rule_name: {patterns+weight} } } }

v9.8 changes (historical):
  - compile_rules_for_config() now reads cfg['paths']['profiles_dirs'] and
    cfg['paths']['rules_dirs'] (lists). Falls back to the single-dir legacy
    keys when the list keys are absent.
  - Name-collision detection: if a profile or rule name is found in more than
    one directory, an error is raised listing both conflicting paths.
  - _read_patterns(): unchanged.
  - load_profile_rules(): unchanged.
"""
import hashlib
import json
import logging
import os
import re

from lib.config import _load_json as _load_json_config, INLINE_COMMENT_RE as _PATTERN_COMMENT_RE


def _read_patterns(path):
    """Read a pattern file, stripping blank lines and bash-style comments."""
    if not path:
        return []
    if not os.path.exists(path):
        logging.debug('kcommit: rule pattern file not found (optional): %s', path)
        return []
    patterns = []
    with open(path, encoding='utf-8', errors='replace') as f:
        for line in f:
            stripped = _PATTERN_COMMENT_RE.sub('', line).strip()
            if stripped:
                patterns.append(stripped)
    return patterns


def active_profile_names(cfg):
    """Return ordered list of active profile names."""
    active = (cfg.get('profiles', {}) or {}).get('active') or []
    if isinstance(active, dict):
        return list(active.keys())
    return list(active)


RULE_SCHEMA = {
    'keywords_whitelist': 'keywords_whitelist.txt',
    'keywords_blacklist': 'keywords_blacklist.txt',
    'path_whitelist':     'path_whitelist.txt',
    'path_blacklist':     'path_blacklist.txt',
    'commit_whitelist':   'commit_whitelist.txt',
    'commit_blacklist':   'commit_blacklist.txt',
}


def _resolve_dirs(cfg, key_plural, default_subdir):
    """Return the directory list for *key_plural* from cfg['paths'].

    Also accepts the singular compatibility aliases ``profiles_dir`` and
    ``rules_dir`` in the derived ``paths`` mapping, normalizing them to the
    same list form used internally.
    Falls back to <config_dir>/<default_subdir> when not set.
    """
    paths = cfg.get('paths', {}) or {}
    if paths.get(key_plural):
        return list(paths[key_plural])
    key_singular = key_plural[:-1] if key_plural.endswith('s') else key_plural
    raw = paths.get(key_singular)
    if raw not in (None, [], ''):
        return list(raw) if isinstance(raw, list) else [raw]
    meta       = cfg.get('_meta', {}) or {}
    config_dir = meta.get('config_dir') or os.getcwd()
    return [os.path.join(config_dir, default_subdir)]


def _find_unique(name, dirs, suffix=''):
    """Find *name* (with optional *suffix*) across *dirs*, enforcing uniqueness.

    Returns the full path of the unique match.
    Raises RuntimeError if the name is found in more than one directory,
    or if it is not found in any directory (returns None in that case).
    """
    found = []
    for d in dirs:
        candidate = os.path.join(d, name + suffix) if suffix else os.path.join(d, name)
        if os.path.exists(candidate):
            found.append(candidate)
    if len(found) > 1:
        paths_str = '\n  '.join(found)
        raise RuntimeError(
            f'name collision: {name!r} found in multiple directories:\n  {paths_str}\n'
            f'Each name must be unique across all search paths.')
    return found[0] if found else None


def _find_preferred(name, primary_dirs, fallback_dirs, suffix=''):
    """Find *name* with preference order: primary dirs first, fallback dirs second.

    Uniqueness is enforced within each tier, but a primary hit cleanly overrides a
    fallback hit with the same name. This is used for D.1 fallback behavior so
    external config trees can override shipped built-in profiles/rules.
    """
    primary = _find_unique(name, primary_dirs, suffix=suffix) if primary_dirs else None
    if primary is not None:
        return primary
    return _find_unique(name, fallback_dirs, suffix=suffix) if fallback_dirs else None

def _rule_name_candidates(name):
    """Return preferred fallback candidate names for legacy external rule names."""
    candidates = [name]
    if name.startswith('artemis_'):
        stripped = name[len('artemis_'):]
        if stripped and stripped not in candidates:
            candidates.append(stripped)
    return candidates



def _merged_patterns(pdata):
    """Return the merged pattern dict from a profile data entry (safe, never None)."""
    if not isinstance(pdata, dict):
        logging.warning('_merged_patterns: expected dict, got %s %r — skipping',
                        type(pdata).__name__, pdata)
        return {}
    return pdata.get('merged', {}) or {}


def compile_rules_for_config(cfg, cache_dir):
    """Compile rules for all active profiles and cache to compiled_rules.json.

    v9.12: writes a deduplicated on-disk schema:
        {
          "rules":    { rule_name: { patterns… } },          # each rule body once
          "profiles": { profile_name: {                       # per-profile metadata
              "rules":  { rule_name: { "weight": N } },       # weight only — body in rules{}
              "merged": { keyword/path lists … }              # union of all rule patterns
          }}
        }

    The in-memory return value remains the inflated form expected by scoring.py
    and prefilter.py:
        { profile_name: { "merged": {…}, "rules": { rule_name: {weight+patterns} } } }
    so no other module needs changing.

    v9.8: searches multiple profiles_dirs and rules_dirs; raises on name collision.
    """
    active        = active_profile_names(cfg)
    if not active:
        raise RuntimeError('no active profiles configured (profiles.active is empty)')

    profiles_dirs = _resolve_dirs(cfg, 'profiles_dirs', 'profiles')
    rules_dirs    = _resolve_dirs(cfg, 'rules_dirs',    'rules')

    # D.1: search the tool's built-in shipped configs as fallback roots after
    # any external config directories. External entries take precedence; built-in
    # entries are only used when no external match exists.
    _tool_root = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
    builtin_profiles_dirs = [os.path.join(_tool_root, 'configs', 'profiles')]
    builtin_rules_dirs    = [os.path.join(_tool_root, 'configs', 'rules')]

    for d in profiles_dirs + builtin_profiles_dirs:
        if not os.path.isdir(d):
            raise RuntimeError(f'profiles directory not found: {d}')
    for d in rules_dirs + builtin_rules_dirs:
        if not os.path.isdir(d):
            raise RuntimeError(f'rules directory not found: {d}')

    # rule_bodies: rule_name -> full pattern dict (shared across profiles)
    rule_bodies   = {}
    # in-memory result (inflated): profile_name -> {merged, rules{name:{weight+patterns}}}
    profiles_mem  = {}

    for name in active:
        prof_path = _find_preferred(name, profiles_dirs, builtin_profiles_dirs, suffix='.json')
        if prof_path is None:
            searched = ', '.join(profiles_dirs)
            raise RuntimeError(
                f'profile {name!r} not found in any profiles directory ({searched})')

        rule_search_dirs = list(rules_dirs)
        for d in builtin_rules_dirs:
            if d not in rule_search_dirs:
                rule_search_dirs.append(d)

        pdata = _load_json_config(prof_path)
        if not pdata:
            raise RuntimeError(f'profile {name!r} not found or empty at {prof_path}')

        # I.6: validate that the 'name' field inside the JSON (if present)
        # matches the filename stem used to load the profile.  A mismatch
        # indicates the file was renamed without updating its content.
        _json_name = pdata.get('name')
        if _json_name is not None and _json_name != name:
            raise RuntimeError(
                f'profile file {os.path.basename(prof_path)!r} declares '
                f'name={_json_name!r} but was loaded as {name!r}. '
                f'Rename the file to {_json_name!r}.json or update the "name" field.')

        rules_cfg = pdata.get('rules') or {}
        if not isinstance(rules_cfg, dict) or not rules_cfg:
            raise RuntimeError(f'profile {name!r} must define a non-empty rules mapping')

        merged_accum = {key: set() for key in RULE_SCHEMA}
        per_rule_mem = {}   # {rule_name: {weight + patterns}}

        for rname, rule_spec in rules_cfg.items():
            # ── resolve weight & extras from profile rule spec ──────────────
            if isinstance(rule_spec, dict):
                try:
                    w = int(rule_spec.get('weight', 50))
                except (TypeError, ValueError):
                    raise RuntimeError(
                        f'rule weight for {rname!r} in profile {name!r} must be an integer')
                extras = {k: v for k, v in rule_spec.items() if k != 'weight'}
            else:
                try:
                    w = int(rule_spec)
                except (TypeError, ValueError):
                    raise RuntimeError(
                        f'rule weight for {rname!r} in profile {name!r} must be an integer, '
                        f'got {rule_spec!r}')
                extras = {}

            # ── load pattern files only once per rule name ──────────────────
            if rname not in rule_bodies:
                rdir = None
                resolved_rname = rname
                for candidate_name in _rule_name_candidates(rname):
                    rdir = _find_preferred(candidate_name, rules_dirs, builtin_rules_dirs)
                    if rdir is not None:
                        resolved_rname = candidate_name
                        break
                if rdir is None:
                    searched = ', '.join(rule_search_dirs)
                    raise RuntimeError(
                        f'rule folder {rname!r} for profile {name!r} not found '
                        f'in any rules directory ({searched})')
                if not os.path.isdir(rdir):
                    raise RuntimeError(
                        f'rule path {rdir!r} for rule {rname!r} in profile {name!r} '
                        f'is not a directory')
                body = {}
                for key, fname in RULE_SCHEMA.items():
                    pats = list(_read_patterns(os.path.join(rdir, fname)))
                    extra_key = key + '_extra'
                    if extra_key in extras:
                        extra_pats = extras[extra_key]
                        if isinstance(extra_pats, list):
                            pats = pats + [str(p) for p in extra_pats]
                    body[key] = pats
                if not any(body[k] for k in RULE_SCHEMA):
                    raise RuntimeError(
                        f'rule {rname!r} in profile {name!r} has no pattern files '
                        f'under {rdir} — at least one *list.txt must be non-empty')
                rule_bodies[rname] = body
            else:
                body = rule_bodies[rname]

            # accumulate merged patterns for this profile
            for key in RULE_SCHEMA:
                merged_accum[key].update(body[key])

            per_rule_mem[rname] = {'weight': w, **body}

        profiles_mem[name] = {
            'merged':      {k: sorted(v) for k, v in merged_accum.items()},
            'rules':       per_rule_mem,
            'description': pdata.get('description', ''),
        }

    # ── Write deduplicated schema ────────────────────────────────────────────
    disk_doc = {
        'rules':    rule_bodies,
        'profiles': {
            pname: {
                'rules':  {rn: {'weight': rv['weight']} for rn, rv in pdata['rules'].items()},
                'merged': pdata['merged'],
            }
            for pname, pdata in profiles_mem.items()
        },
    }
    # Compute a hash over the input profile/rule files so load_profile_rules()
    # can detect stale caches automatically.
    _hash_parts = []
    for _pname in sorted(profiles_mem):
        _hash_parts.append(_pname)
        _pdir = _find_unique(_pname, profiles_dirs, suffix='.json')
        if _pdir:
            _hash_parts.append(open(_pdir, 'rb').read().hex())
    # E.9: also hash all rule files so cache is invalidated on rule changes
    for _rdir in rules_dirs:
        if not os.path.isdir(_rdir):
            continue
        for _rf in sorted(os.listdir(_rdir)):
            _rfp = os.path.join(_rdir, _rf)
            if os.path.isfile(_rfp):
                _hash_parts.append(open(_rfp, 'rb').read().hex())
    schema_hash = hashlib.sha1('|'.join(_hash_parts).encode()).hexdigest()[:16]

    cache_path = os.path.join(cache_dir, 'compiled_rules.json')
    os.makedirs(os.path.dirname(cache_path), exist_ok=True)
    disk_doc['schema_hash'] = schema_hash
    with open(cache_path, 'w', encoding='utf-8') as f:
        json.dump(disk_doc, f, indent=2, sort_keys=True)
        f.write('\n')
    return profiles_mem


def load_profile_rules(cfg):
    """Load and inflate compiled_rules.json into the in-memory form:
        { profile_name: { "merged": {…}, "rules": { rule_name: {weight+patterns} } } }
    Recompiles if the cache is missing.
    """
    paths      = cfg.get('paths', {}) or {}
    work_dir   = paths.get('work_dir') or cfg.get('project', {}).get('work_dir', './work')
    cache_dir  = paths.get('cache_dir') or os.path.join(work_dir, 'cache')
    cache_path = os.path.join(cache_dir, 'compiled_rules.json')

    def _needs_recompile(cache_p):
        if not os.path.exists(cache_p):
            return True, 'not found'
        try:
            with open(cache_p, encoding='utf-8') as f:
                d = json.load(f)
        except Exception:
            return True, 'unreadable'
        cached_hash = d.get('schema_hash')
        if not cached_hash:
            return True, 'no schema_hash (pre-v9.12 cache)'
        return False, None

    _stale, _reason = _needs_recompile(cache_path)
    if _stale:
        if _reason == 'unreadable':
            logging.warning('profile_rules: compiled_rules.json %s — recompiling.', _reason)
        elif _reason == 'no schema_hash (pre-v9.12 cache)':
            logging.info('profile_rules: compiled_rules.json %s — recompiling. '
                         'Re-run stage 00 once to persist the updated cache.', _reason)
        else:
            logging.debug('profile_rules: compiled_rules.json %s — recompiling.', _reason)
        return compile_rules_for_config(cfg, cache_dir)

    with open(cache_path, encoding='utf-8') as f:
        doc = json.load(f)

    rule_bodies = doc['rules']
    inflated    = {}
    for pname, pdata in doc['profiles'].items():
        per_rule = {
            rname: {'weight': rmeta.get('weight', 50), **rule_bodies[rname]}
            for rname, rmeta in (pdata.get('rules') or {}).items()
        }
        inflated[pname] = {'merged': pdata.get('merged') or {}, 'rules': per_rule}
    return inflated
